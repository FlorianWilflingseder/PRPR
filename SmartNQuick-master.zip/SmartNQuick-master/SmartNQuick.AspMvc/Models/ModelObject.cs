﻿namespace SmartNQuick.AspMvc.Models
{
	public class ModelObject : Contracts.IIdentifiable
	{
		public int Id { get; set; }
	}
}
