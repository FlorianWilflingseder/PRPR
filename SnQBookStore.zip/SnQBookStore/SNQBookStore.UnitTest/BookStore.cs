using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xunit.Sdk;
using System;
using System.Threading.Tasks;
using SnQBookStore.Contracts.Persistence.App;

namespace SnQBookStore.UnitTest
{
    [TestClass]
    public class BookStore
    {
        public static SnQBookStore.Contracts.Client.IControllerAccess<IBook> CreateController()
        {
            return SnQBookStore.Logic.Factory.Create<IBook>();
        }

        public static async void DeleteAllAsyncEnities()
        {

            using var ctrl = CreateController();

            foreach (var item in await ctrl.GetAllAsync())
            {
                await ctrl.DeleteAsync(item.Id);
            }

            await ctrl.SaveChangesAsync();
        }


        [ClassInitialize]
        public static void ClassInitialize(TestContext test)
        {
            DeleteAllAsyncEnities();
        }
        [ClassCleanup]
        public static void ClassCleanup()
        {
            DeleteAllAsyncEnities();
        }
        [TestInitialize]
        public void InitDb()
        {

        }

        [TestCleanup]
        public void Cleanup()
        {
            DeleteAllAsyncEnities();
        }

        [TestMethod]
        public void Insert_ValidISBN_ResultPersitenceEntity()
        {
            DeleteAllAsyncEnities();
            IBook expected = null;
            string expectedISBN = null;

            Task.Run(async () =>
            {
                using var ctrl = CreateController();
                var entity = await ctrl.CreateAsync();

                expectedISBN = "0471190470";
                entity.ISBNNumber = expectedISBN;
                entity.Author = "";
                entity.Description = "";
                expected = await ctrl.InsertAsync(entity);
                await ctrl.SaveChangesAsync();
            }).Wait();

            Assert.IsNotNull(expected);
            Assert.AreNotEqual(0, expected.Id);
            Assert.AreEqual(expected.ISBNNumber, expectedISBN);
        }

        [TestMethod]
        [ExpectedException(typeof(Logic.Modules.Exception.LogicException))]
        public async Task Insert_InvalidISBN_ResultPersitenceEntity()
        {
           
            IBook expected = null;
            string expectedISBN = null;

            using var ctrl = CreateController();
            var entity = await ctrl.CreateAsync();

            expectedISBN = "0471590470";
            entity.ISBNNumber = expectedISBN;
            entity.Author = "";
            entity.Description = "";
            expected = await ctrl.InsertAsync(entity);
            await ctrl.SaveChangesAsync();
        }


        [TestMethod]
        public void Edit_ValidISBN_ResultPersitenceEntity()
        {
            
            IBook expected = null;
            string insertingISBN = null;
            IBook getIsbnById = null;

            Task.Run(async () =>
            {
                using var ctrl = CreateController();
                var entity = await ctrl.CreateAsync();

                insertingISBN = "0471190470";
                entity.ISBNNumber = insertingISBN;
                entity.Author = "";
                entity.Description = "";
                var insert = await ctrl.InsertAsync(entity);
                await ctrl.SaveChangesAsync();

                getIsbnById = await ctrl.GetByIdAsync(insert.Id);
                if (getIsbnById != null)
                {
                    string newIsbn = "2231694166";
                    getIsbnById.ISBNNumber = newIsbn;
                    await ctrl.UpdateAsync(getIsbnById);
                    await ctrl.SaveChangesAsync();
                }

                expected = await ctrl.GetByIdAsync(getIsbnById.Id);
            }).Wait();
            Assert.IsNotNull(expected);
            Assert.AreNotEqual(0, expected.Id);
            Assert.AreNotEqual(expected.ISBNNumber, insertingISBN);
        }

    
        [TestMethod]
        [ExpectedException(typeof(Logic.Modules.Exception.LogicException))]
        public async Task Edit_InvalidISBN_ResultPersitenceEntity()
        {
           
            IBook expected = null;
            string insertingISBN = null;
            IBook getIsbnById = null;

            using var ctrl = CreateController();
            var entity = await ctrl.CreateAsync();

            insertingISBN = "0471190470";
            entity.ISBNNumber = insertingISBN;
            entity.Author = "aaa";
            entity.Description = "ajdis";

            var insert = await ctrl.InsertAsync(entity);
            await ctrl.SaveChangesAsync();

            getIsbnById = await ctrl.GetByIdAsync(insert.Id);
            if(getIsbnById != null)
            {
                string newIsbn = "0471199470";
                getIsbnById.ISBNNumber = newIsbn;
                await ctrl.UpdateAsync(getIsbnById);
                await ctrl.SaveChangesAsync();
            }

            expected = await ctrl.GetByIdAsync(getIsbnById.Id);
        }
    }
}
