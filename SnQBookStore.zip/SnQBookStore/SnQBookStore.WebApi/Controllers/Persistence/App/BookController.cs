//@GeneratedCode
namespace SnQBookStore.WebApi.Controllers.Persistence.App
{
    using Microsoft.AspNetCore.Mvc;
    using TContract = Contracts.Persistence.App.IBook;
    using TModel = Transfer.Models.Persistence.App.Book;
    [ApiController]
    [Route("Controller")]
    public partial class BooksController : WebApi.Controllers.GenericController<TContract, TModel>
    {
    }
}
