﻿using SnQBookStore.Contracts.Persistence.App;
using SnQBookStore.Logic.Entities.Persistence.App;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnQBookStore.Logic.Controllers.Persistence.App
{
    partial class BookController
    {
        public override async Task<IBook> CreateAsync()
        {
            var entity = await base.CreateAsync().ConfigureAwait(false);

            entity.CreateDate = DateTime.Now;
            return entity;
        }
        protected override Book BeforeInsert(Book entity)
        {
            if (CommonBase.Validator.Number.CheckISBN10(entity.ISBNNumber) == false)
            {
                throw new Logic.Modules.Exception.LogicException(Modules.Exception.ErrorType.InvalidISBN10Number);
            }
            return base.BeforeInsert(entity);
        }

        protected override Book BeforeUpdate(Book entity)
        {
            if (CommonBase.Validator.Number.CheckISBN10(entity.ISBNNumber) == false)
            {
                throw new Logic.Modules.Exception.LogicException(Modules.Exception.ErrorType.InvalidISBN10Number);
            }
            return base.BeforeUpdate(entity);
        }
    }
}
