//@GeneratedCode
namespace SnQBookStore.Logic.Entities.Persistence.App
{
    partial class Book : VersionEntity
    {
    }
}
