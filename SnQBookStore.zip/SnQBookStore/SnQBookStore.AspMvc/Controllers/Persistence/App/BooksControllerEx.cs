﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SnQBookStore.AspMvc.Controllers.Persistence.App
{
    partial class BooksController
    {
    }
}
