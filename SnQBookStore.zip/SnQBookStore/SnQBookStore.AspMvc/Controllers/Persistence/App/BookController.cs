//@GeneratedCode
namespace SnQBookStore.AspMvc.Controllers.Persistence.App
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using TContract = Contracts.Persistence.App.IBook;
    using TModel = AspMvc.Models.Persistence.App.Book;
    public partial class BooksController : AspMvc.Controllers.GenericController<TContract, TModel>
    {
    }
}
