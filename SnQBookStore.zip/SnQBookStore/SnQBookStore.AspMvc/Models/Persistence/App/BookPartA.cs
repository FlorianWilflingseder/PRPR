//@GeneratedCode
namespace SnQBookStore.AspMvc.Models.Persistence.App
{
    partial class Book : VersionModel
    {
    }
}
