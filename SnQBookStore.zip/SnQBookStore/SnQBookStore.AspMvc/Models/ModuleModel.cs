//@CodeCopy
//MdStart

namespace SnQBookStore.AspMvc.Models
{
    public partial class ModuleModel : ModelObject
    {
    }
}
//MdEnd
