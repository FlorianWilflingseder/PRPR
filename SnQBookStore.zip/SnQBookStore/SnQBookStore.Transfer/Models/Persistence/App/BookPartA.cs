//@GeneratedCode
namespace SnQBookStore.Transfer.Models.Persistence.App
{
    partial class Book : VersionModel
    {
    }
}
