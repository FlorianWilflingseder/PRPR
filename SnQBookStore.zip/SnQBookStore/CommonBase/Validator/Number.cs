﻿using CommonBase.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonBase.Validator
{
    public static class Number
    {
        public static bool CheckISBN10(string number)
        {
            number.CheckArgument(nameof(number));
            int sum = 0;
            if(number != null && number.Length == 10)
            {
                for (int i = 0; i < number.Length - 1; i++)
                {
                    if(char.IsDigit(number[i]))
                    {
                        int isbnInt = number[i] - '0';

                        sum += (isbnInt * (i + 1));
                    }
                }

                sum = sum % 11;

                if (sum == 10 && ('X' == number[9]))
                    return true;
                else if(sum == (number[9] - '0'))
                {
                    return true;
                }

            }
            return false;
        }
    }
}
