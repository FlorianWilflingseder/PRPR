//@GeneratedCode
namespace SnQBookStore.Adapters
{
    public static partial class Factory
    {
        public static Contracts.Client.IAdapterAccess<I> Create<I>()
        {
            Contracts.Client.IAdapterAccess<I> result = null;
            if (Adapter == AdapterType.Controller)
            {
                if (typeof(I) == typeof(SnQBookStore.Contracts.Persistence.App.IBook))
                {
                    result = new Controller.GenericControllerAdapter<SnQBookStore.Contracts.Persistence.App.IBook>() as Contracts.Client.IAdapterAccess<I>;
                }
            }
            else if (Adapter == AdapterType.Service)
            {
                if (typeof(I) == typeof(SnQBookStore.Contracts.Persistence.App.IBook))
                {
                    result = new Service.GenericServiceAdapter<SnQBookStore.Contracts.Persistence.App.IBook, Transfer.Models.Persistence.App.Book>(BaseUri, "Books") as Contracts.Client.IAdapterAccess<I>;
                }
            }
            return result;
        }
        public static Contracts.Client.IAdapterAccess<I> Create<I>(string sessionToken)
        {
            Contracts.Client.IAdapterAccess<I> result = null;
            if (Adapter == AdapterType.Controller)
            {
                if (typeof(I) == typeof(SnQBookStore.Contracts.Persistence.App.IBook))
                {
                    result = new Controller.GenericControllerAdapter<SnQBookStore.Contracts.Persistence.App.IBook>(sessionToken) as Contracts.Client.IAdapterAccess<I>;
                }
            }
            else if (Adapter == AdapterType.Service)
            {
                if (typeof(I) == typeof(SnQBookStore.Contracts.Persistence.App.IBook))
                {
                    result = new Service.GenericServiceAdapter<SnQBookStore.Contracts.Persistence.App.IBook, Transfer.Models.Persistence.App.Book>(sessionToken, BaseUri, "Books") as Contracts.Client.IAdapterAccess<I>;
                }
            }
            return result;
        }
    }
}
