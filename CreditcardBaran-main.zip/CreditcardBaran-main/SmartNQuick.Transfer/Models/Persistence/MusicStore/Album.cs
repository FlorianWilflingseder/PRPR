﻿//@Ignore

namespace SmartNQuick.Transfer.Models.Persistence.MusicStore
{
	class Album
	{
	}
}
