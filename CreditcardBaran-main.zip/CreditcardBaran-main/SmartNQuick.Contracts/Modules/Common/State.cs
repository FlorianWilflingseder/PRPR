﻿//@BaseCode

namespace SmartNQuick.Contracts.Modules.Common
{
	public enum State : int
	{
		Locked = 0,
		Active = 1,
	}
}
