﻿//@BaseCode

namespace CommonBase.Extensions
{
	public static class TypeExtensions
	{
	}
}
