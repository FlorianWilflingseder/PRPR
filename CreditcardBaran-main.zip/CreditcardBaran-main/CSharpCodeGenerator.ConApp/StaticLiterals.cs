﻿//@BaseCode

namespace CSharpCodeGenerator.ConApp
{
	public static class StaticLiterals
	{
		public static string ContractsExtension => ".Contracts";
	}
}
