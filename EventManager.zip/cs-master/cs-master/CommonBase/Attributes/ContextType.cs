﻿namespace CommonBase.Attributes
{
	public enum ContextType : byte
	{
		Table = 1,
		View = 2,
	}
}
