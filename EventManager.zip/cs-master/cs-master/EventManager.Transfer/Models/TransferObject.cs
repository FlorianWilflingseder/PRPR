﻿namespace EventManager.Transfer.Models
{
	public partial class TransferObject
	{
	}
}
